# خادم MCP — دفترة × صبرة تك

ربط Claude مباشرة بحساب **صبرة تك** في دفترة، لاستعلام العملاء والفواتير والمنتجات من داخل المحادثة.

---

## الأدوات المتاحة

| الأداة | الوظيفة |
|---|---|
| `list_clients` | قائمة العملاء (صفحات) |
| `get_client` | عميل واحد برقمه |
| `list_invoices` | قائمة الفواتير (صفحات) |
| `get_invoice` | فاتورة واحدة برقمها |
| `list_products` | قائمة المنتجات/الخدمات |

---

## الخطوة 1 — مفتاح API من دفترة

1. ادخل حساب **صبرة تك** في دفترة.
2. القائمة الرئيسية → **الإعدادات** → **API** → **API Keys**.
3. اضغط **Generate API key** → اكتب اسمًا (مثلاً: Claude MCP) → **Submit**.
4. انسخ المفتاح واحتفظ به.
5. احتفظ أيضًا بالنطاق الفرعي (subdomain): الجزء قبل `.daftra.com` في رابط دخولك.
   - مثال: لو الرابط `https://sabratech.daftra.com` فالنطاق هو `sabratech`.

## الخطوة 2 — رفع المشروع على GitHub (من الجوال)

1. من متصفح الجوال ادخل github.com وسجّل الدخول.
2. **New repository** → الاسم: `daftra-sabratech-mcp` → اختر **Private** → Create.
3. **Add file → Upload files** → ارفع الملفات الثلاثة:
   - `server.py`
   - `requirements.txt`
   - `README.md`
4. **Commit changes**.

## الخطوة 3 — النشر على Render (مجاني)

1. ادخل render.com وسجّل بحساب GitHub.
2. **New → Web Service** → اختر مستودع `daftra-sabratech-mcp`.
3. الإعدادات:
   - **Name**: اسم عشوائي طويل يصعب تخمينه، مثال: `sabratech-x7k2m9q4`
   - **Runtime**: Python 3
   - **Build Command**: `pip install -r requirements.txt`
   - **Start Command**: `python server.py`
   - **Instance Type**: Free
4. قسم **Environment Variables** أضف:
   - `DAFTRA_SUBDOMAIN` = النطاق الفرعي (مثال: `sabratech`)
   - `DAFTRA_APIKEY` = المفتاح الذي أنشأته في الخطوة 1
5. اضغط **Deploy** وانتظر حتى تظهر حالة **Live**.
6. رابط الخادم سيكون:
   `https://sabratech-x7k2m9q4.onrender.com/mcp`
   (لاحظ إضافة `/mcp` في نهاية الرابط)

## الخطوة 4 — الربط في Claude

1. تطبيق Claude → **Settings** → **Connectors**.
2. **Add custom connector**.
3. الصق الرابط: `https://اسم-خدمتك.onrender.com/mcp`
4. احفظ، ثم فعّل الموصل داخل المحادثة من قائمة الأدوات.

## الاختبار

اكتب في محادثة Claude:

> اعرض أول عميل في صبرة تك باستخدام list_clients

---

## تنبيهات

- **الأمان**: الخادم بلا مصادقة؛ حماية الرابط تعتمد على سريته. لا تشارك الرابط مع أحد، واجعل اسم الخدمة عشوائيًا. مفتاح دفترة محفوظ في متغيرات البيئة على Render ولا يظهر في الكود.
- **الخطة المجانية في Render**: الخادم ينام بعد 15 دقيقة خمول، وأول استدعاء بعده يتأخر 30–60 ثانية. هذا طبيعي. للاستخدام اليومي الجاد انتقل للخطة المدفوعة (~7$/شهر).
- **تعديل المفتاح لاحقًا**: من Render → الخدمة → Environment → عدّل القيمة → سيعاد التشغيل تلقائيًا.
